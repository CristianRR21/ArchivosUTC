@extends('layout.app')
@section('contenido')
<br>
<h1 style="text-align:center" >Mapa de clientes</h1>
<div class='container'>
<div id="mapa-clientes" style="border:2px solid black;height:500px;width: 100%">

</div>
</div>
<script type="text/javascript">

      function initMap(){
        
        var latitud_longitud= new google.maps.LatLng(-0.9374805,-78.6161327);
        var mapa=new google.maps.Map(
          document.getElementById('mapa-clientes'),
          {
            center:latitud_longitud,
            zoom:7,
            mapTypeId:google.maps.MapTypeId.ROADMAP
          }
        );

        @foreach($clientes as $clienteTmp)
        var coordenadaCliente= new google.maps.LatLng({{$clienteTmp->latitud}},{{$clienteTmp->longitud}});
        var marcador=new google.maps.Marker({
          position:coordenadaCliente,
          map:mapa,
          icon:'https://icons.iconarchive.com/icons/diversity-avatars/avatars/48/barack-obama-icon.png',
          title:"{{$clienteTmp->apellido}} {{$clienteTmp->nombre}}",
          draggable:false
        });        
        @endforeach

      }

</script>
@endsection