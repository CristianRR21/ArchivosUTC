<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado Clientes</title>
</head>
<body>
    @extends('layout.app')
    @section('contenido')


     <script>

        function confirmarEliminacion(id)
        {
            Swal.fire({
            title: "¿Estas seguro de eliminar el cliente?",
            text: "No se podrá recuperar el registro!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Si,eliminar!",
            cancelButtonText: "Cancelar"
            }).then((result) => {
            if (result.isConfirmed) {
              
               document.getElementById('form-eliminar-' + id).submit();
            }
            });
        }

    </script>
    <h1 style="text-align:center">Listado de clientes</h1>
    <a href="{{route('clientes.create') }}" class="btn btn-success">Nuevo Cliente</a>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="{{ url('clientes/mapa') }}" class="btn btn-warning">Ver Mapa Global</a>
    <br><br>
    <table class="table table-bordered table-striped table-hover" id= "tbl_clientes">
       <thead>
    <tr>
        <th>ID</th>
        <th>CEDULA</th>
        <th>APELLIDO</th>
        <th>NOMBRE</th>
        <th>LATITUD</th>
        <th>LONGITUD</th>
        <th>ACCIONES</th>
    </tr>
</thead>

        <tbody>
            @foreach($clientes as $clienteTmp)
            <tr>
                <td>{{$clienteTmp->id}}</td>
                <td>{{$clienteTmp->cedula}}</td>
                <td>{{$clienteTmp->apellido}}</td>
                <td>{{$clienteTmp->nombre}}</td>
                <td>{{$clienteTmp->latitud}}</td>
                <td>{{$clienteTmp->longitud}}</td>
                <th>
                    <a href="{{ route('clientes.edit', $clienteTmp->id) }}" class="btn btn-sm btn-primary">Editar</a>                   
                    
                  <form id="form-eliminar-{{ $clienteTmp->id }}" action="{{ route('clientes.destroy', $clienteTmp->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="button" class="btn btn-sm btn-danger"
                                onclick="confirmarEliminacion({{ $clienteTmp->id }})">
                            Eliminar
                        </button>
                    </form>


                
                </th>
            </tr>

            @endforeach

        </tbody>
    </table>








<script>
$(document).ready(function() {
    let table = new DataTable('#tbl_clientes', {
        language: {
            url: 'https://cdn.datatables.net/plug-ins/2.3.1/i18n/es-ES.json'
        },
        dom: 'Bfrtip', 
        buttons: [
            'copy',
            'csv',
            'excel',
            'pdf',
            'print'
        ]
    });
});
</script>

@endsection
</html>