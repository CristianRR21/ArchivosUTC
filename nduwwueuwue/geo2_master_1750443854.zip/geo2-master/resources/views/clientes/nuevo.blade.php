@extends('layout.app')
@section('contenido')
<form action="{{ route('clientes.store')}}" id="fr_nuevo_cliente" name="fr_nuevo_cliente"
        method="post" class="container mt-5">
    @csrf
    <h1 style="text-align:center">Registrar Nuevo Cliente</h1><br>
    <label for=""><b>Cedula:</b></label><br>
    <input  type="text" name="cedula" id="cedula" class="form form-control"> <br> <br>
    <label for=""><b>Apellido:</b></label><br>
    <input  type="text" name="apellido" id="apellido"class="form form-control"> <br> <br>
    <label for=""><b>Nombre:</b></label><br>
    <input  type="text" name="nombre" id="nombre"class="form form-control"> <br> <br>
    <label for=""><b>Latitud:</b></label><br>
    <input readonly type="text" name="latitud" id="latitud"class="form form-control"> <br> <br>
    <label for=""><b>Longitud:</b></label><br>
    <input readonly type="text" name="longitud" id="longitud"class="form form-control"> <br> <br>

    <br>
      <div class="" id="mapa_cliente" style="border:1px solid black; height:250px;
            width:50%"> </div>
    <br>
    <button type="submit" class="btn btn-success">Guardar</button> &nbsp;&nbsp;&nbsp;&nbsp; 
    <a href="{{ route('clientes.index') }}" class="btn btn-warning">Cancelar</a>
</form>



<script type="text/javascript">

      function initMap(){
        
        var latitud_longitud= new google.maps.LatLng(-0.9374805,-78.6161327);
        var mapa=new google.maps.Map(
          document.getElementById('mapa_cliente'),
          {
            center:latitud_longitud,
            zoom:7,
            mapTypeId:google.maps.MapTypeId.ROADMAP
          }
        );
        var marcador=new google.maps.Marker({
          position:latitud_longitud,
          map:mapa,
          title:"Seleccione la direccion",
          draggable:true
        });
        google.maps.event.addListener(
          marcador,
          'dragend',
          function(event){
            var latitud=this.getPosition().lat();
            var longitud=this.getPosition().lng();
            /*alert("LATITUD: "+latitud);
            alert("LONGITUD: "+longitud);*/
            document.getElementById("latitud").value=latitud;
            document.getElementById("longitud").value=longitud;
          }
        );
      }

</script>

<script>
    $("#fr_nuevo_cliente").validate({
        rules: {
            cedula: {
                required: true,
                minlength: 10,
                maxlength: 10
            },
            apellido: {
                required: true,
                minlength: 5,
                maxlength: 20
            },
            nombre: {
                required: true,
                minlength: 5,
                maxlength: 20
            },
            latitud: {
                required: true
            },
            longitud: {
                required: true
            }
        },
        messages: {
            cedula: {
                required: "Por favor ingrese la cédula",
                minlength: "La cédula debe tener 10 caracteres",
                maxlength: "La cédula debe tener 10 caracteres"
            },
            apellido: {
                required: "Por favor ingrese el apellido",
                minlength: "El apellido debe tener al menos 5 caracteres",
                maxlength: "El apellido no debe superar los 20 caracteres"
            },
            nombre: {
                required: "Por favor ingrese el nombre",
                minlength: "El nombre debe tener al menos 5 caracteres",
                maxlength: "El nombre no debe superar los 20 caracteres"
            },
            latitud: {
                required: "Debe seleccionar una ubicación en el mapa"
            },
            longitud: {
                required: "Debe seleccionar una ubicación en el mapa"
            }
        }
    });
</script>


@endsection