<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Predios</title>
</head>
<body>
    @extends('layout.app')
    @section('contenido')
      <script>

        function confirmarEliminacion(id)
        {
            Swal.fire({
            title: "¿Estas seguro de eliminar el predio?",
            text: "No se podrá recuperar el registro!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Si,eliminar!",
            cancelButtonText: "Cancelar"
            }).then((result) => {
            if (result.isConfirmed) {
              
               document.getElementById('form-eliminar-' + id).submit();
            }
            });
        }

    </script>

    <h1 style="text-align: center">Listado de Predios</h1>

    <a href="{{route ('predios.create') }}" class="btn btn-success">Nuevo Predio</a><br><br>

    <table id="tbl_predios">
        <thead>
            <tr>
                <th>ID</th>
                <th>PROPIETARIO</th>
                <th>CLAVE CATASTRAL</th>
                <th>LATITUD UNO </th>
                <th>LONGITUD UNO </th>
                
                <th>LATITUD DOS </th>
                <th>LONGITUD DOS </th>
                
                <th>LATITUD TRES </th>
                <th>LONGITUD TRES </th>
                
                <th>LATITUD CUATRO </th>
                <th>LONGITUD CUATRO </th>
                
                <th>ACCIONES</th>

            </tr>
        </thead>
        <tbody>


        @foreach ($predios as $predioTmp)
        <tr>
            <td>{{$predioTmp->id}}</td>
            <td>{{$predioTmp->propietario}}</td>
            <td>{{$predioTmp->clave}}</td>
            <td>{{$predioTmp->latitudUno}}</td>
            <td>{{$predioTmp->longitudUno}}</td>
            <td>{{$predioTmp->latitudDos}}</td>
            <td>{{$predioTmp->longitudDos}}</td>
            <td>{{$predioTmp->latitudTres}}</td>
            <td>{{$predioTmp->longitudTres}}</td>
            <td>{{$predioTmp->latitudCuatro}}</td>
            <td>{{$predioTmp->longitudCuatro}}</td>
            <td>
                <a href="{{route ('predios.edit',$predioTmp->id)}}" class="btn btn-primary">Editar</a>

                <form id="form-eliminar-{{ $predioTmp->id }}" action="{{ route('predios.destroy', $predioTmp->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="button" class="btn btn-sm btn-danger"
                                onclick="confirmarEliminacion({{ $predioTmp->id }})">
                            Eliminar
                        </button>
                    </form>

            </td>
        </tr>
                @endforeach
           
        </tbody>
    </table>
<script>
$(document).ready(function() {
    let table = new DataTable('#tbl_predios', {
        language: {
            url: 'https://cdn.datatables.net/plug-ins/2.3.1/i18n/es-ES.json'
        },
        dom: 'Bfrtip', 
        buttons: [
            'copy',
            'csv',
            'excel',
            'pdf',
            'print'
        ]
    });
});
</script>

@endsection
</html>