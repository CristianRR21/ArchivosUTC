<?php

use Illuminate\Support\Facades\Route;
//IMportando el controlador

use App\Http\Controllers\ClienteController;
use App\Http\Controllers\PredioController;


Route::get('/', function () {
    return view('welcome');
});


Route::get('/clientes/mapa',[ClienteController::class,'mapa']);
//habilitamos el acces al contolador
Route::resource('clientes',ClienteController::class);
//habilitando a los recursos del controlador predios
Route::resource('predios',PredioController::class);