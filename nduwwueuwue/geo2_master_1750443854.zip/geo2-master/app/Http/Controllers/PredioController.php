<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Predio;

class PredioController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $predios=Predio::all();
        return view('predios.index',compact("predios"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('predios.nuevo');
    }

    /**
     * Store a newly created resource in storage.
     */
   public function store(Request $request)
{
    $datos = [
        'propietario' => $request->propietario,
        'clave' => $request->clave,
        'latitudUno' => $request->latitud1,
        'longitudUno' => $request->longitud1,
        'latitudDos' => $request->latitud2,
        'longitudDos' => $request->longitud2,
        'latitudTres' => $request->latitud3,
        'longitudTres' => $request->longitud3,
        'latitudCuatro' => $request->latitud4,
        'longitudCuatro' => $request->longitud4,
    ];

    

    Predio::create($datos);

    return redirect()->route('predios.index')->with('mensaje', 'Predio creado con éxito');
}


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
     
        //
         $predio = Predio::findOrFail($id);
        return view('predios.editar', compact("predio"));
    }

    /**
     * Update the specified resource in storage.
     */

     public function update(Request $request, string $id)
    {
    $predio = Predio::findOrFail($id);

    $datos = [
        'propietario' => $request->propietario,
        'clave' => $request->clave,
        'latitudUno' => $request->latitud1,
        'longitudUno' => $request->longitud1,
        'latitudDos' => $request->latitud2,
        'longitudDos' => $request->longitud2,
        'latitudTres' => $request->latitud3,
        'longitudTres' => $request->longitud3,
        'latitudCuatro' => $request->latitud4,
        'longitudCuatro' => $request->longitud4,
    ];

    $predio->update($datos);

    return redirect()->route('predios.index')->with('mensaje', 'Predio actualizado con éxito');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        Predio::destroy($id);
        return redirect()->route('predios.index');
    }
}
