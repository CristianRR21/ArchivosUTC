<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// Importar el modelo cliente

use App\Models\Cliente;

class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //Consulta de Clientes en la BDD
        $clientes=Cliente::all();
        //rendizar la vista y pasar datos
        return view('clientes.index',compact("clientes"));

    }

    /**fucion que renderiza un mapa con las ubicaciones (Lat/Lon) */
    public function mapa()
    {
        //Consulta de Clientes en la BDD
        $clientes=Cliente::all();
        //rendizar la vista y pasar datos
        return view('clientes.mapa',compact("clientes"));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //Rendierizando el forlatio para crea cleitne
        return view('clientes.nuevo');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //capturar los valores y almacenarlos en la bd son los names de los input
        $datos=[

            'cedula'=>$request->cedula,
            'apellido'=>$request->apellido,
            'nombre'=>$request->nombre,
            'latitud'=>$request->latitud,
            'longitud'=>$request->longitud,
        ];
        Cliente::create($datos);
        return redirect()->route('clientes.index')->with('mensaje', 'Cliente creado con éxito');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //     

        $cliente = Cliente::findOrFail($id);
        return view('clientes.editar', compact("cliente"));

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
         $cliente = Cliente::findOrFail($id);

        $cliente->update($request->all());

        $cliente->update($request->all());

        return redirect()->route('clientes.index')->with('mensaje', 'Cliente actualizado con éxito');
            
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        Cliente::destroy($id);
        return redirect()->route('clientes.index');

    }
}
