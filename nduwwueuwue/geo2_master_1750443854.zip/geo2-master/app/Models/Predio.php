<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;



class Predio extends Model
{
    //
    use HasFactory;
    protected $fillable=[

        'propietario',
        'clave',

        'latitudUno',
        'longitudUno',
        
        'latitudDos',
        'longitudDos',

        'latitudTres',
        'longitudTres',

        'latitudCuatro',
        'longitudCuatro',

    ];
}
